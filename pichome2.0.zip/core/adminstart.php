<?php
/*
 * @copyright   QiaoQiaoShiDai Internet Technology(Shanghai)Co.,Ltd
 * @license     https://www.oaooa.com/licenses/
 * 
 * @link        https://www.oaooa.com
 * @author      zyx(zyx@oaooa.com)
 */
require __DIR__.'/coreBase.php';
$dzz = C::app();
Hook::listen('dzz_initbefore');//初始化前钩子
$dzz->init();

$admincp = new dzz_admincp();
$admincp->core  =  $dzz;
$admincp->init();
Hook::listen('dzz_initafter');//初始化后钩子
$files = Hook::listen('dzz_route',$_GET);//路由钩子，返回文件路径
foreach($files as $v){
    require $v;//包含文件
}

