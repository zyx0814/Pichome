<?php
if(!defined('IN_OAOOA')) {
	exit('Access Denied');
}

class CException extends Exception{

}
?>