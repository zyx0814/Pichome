<?php
$lang = array (
    'appname'=>'System log',
	'logs' => 'Operation record',
    'systemlog_setting'=>'setting',
    'systemlog_list'=>'Log list',
    'os'=>'Device',
	'info'=>'information',
	'loginfo'=>'Log information',
	'visit'=>'Access page',
	'from'=>'Source page',
	'logswitch'=>'Log switch',
	'logtype'=>'Log type',
	'logtypename'=>'Log type name',
	'logtype'=>'Log type',
	'logflag'=>'Log identifier',
	'Logtag'=>'Log tag',
	'repeat'=>'repeat',
	'Update_setting'=>'Update log settings'
	
);

?>