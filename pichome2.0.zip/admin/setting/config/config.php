<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/9/7
 * Time: 15:34
 */
return array(
    'allow_robot'=>false,
    'default_op'=>'cloudindex',
    // 'default_op'=>'index',
);