<?php
$lang = array (
	'appname'=>'System Tool',
    'systemupgrade'=>'online upgrade',
	'tools_updatecache_memory'=>'Memory Cache'
);
?>