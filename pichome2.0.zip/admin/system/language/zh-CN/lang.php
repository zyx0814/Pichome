<?php
$lang = array (
	'appname'=>'系统工具',
    'systemupgrade'=>'在线升级',
	'tools_updatecache_memory'=>'内存缓存'
);
?>